import renderPage from "./UI";

renderPage();